package com.altimetrik.stockInvertory.serviceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altimetrik.stockInventory.Repository.StockRepository;
import com.altimetrik.stockInventory.model.Stock;
import com.altimetrik.stockInventory.service.UpdateStock;
@Service
public class UpdateStockImpl implements UpdateStock {
	@Autowired
	StockRepository stockRepository;

	@Override
	public void updateStock(Stock updateStock) {
		// TODO Auto-generated method stub
		
		if(updateStock.getStockName()!=null) {
			String name = updateStock.getStockName();
			Optional<Stock> storedValue= stockRepository.findByStockName(name);
			if(null!=storedValue) {
				stockRepository.save(updateStock);				
			}
			else {
				System.out.println("Stock Item is not present in db");
			}
		}
	}


}
