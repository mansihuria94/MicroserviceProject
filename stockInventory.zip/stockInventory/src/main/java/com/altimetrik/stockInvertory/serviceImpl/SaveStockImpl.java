package com.altimetrik.stockInvertory.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altimetrik.stockInventory.Repository.StockRepository;
import com.altimetrik.stockInventory.model.Stock;
import com.altimetrik.stockInventory.service.SaveStock;

@Service
public class SaveStockImpl implements SaveStock {
	@Autowired
	StockRepository stockRepository;

	@Override
	public void saveStock(Stock addStock) {
		// TODO Auto-generated method stub
		stockRepository.save(addStock);
	}


}
