package com.altimetrik.stockInvertory.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altimetrik.stockInventory.Repository.StockRepository;
import com.altimetrik.stockInventory.model.Stock;
import com.altimetrik.stockInventory.service.DisplayStock;

@Service
public class DisplayStockImpl implements DisplayStock {
	@Autowired
	StockRepository stockRepository;

	@Override
	public Optional<Stock> displayStock(int stockId) {
		// TODO Auto-generated method stub
		return stockRepository.findById(stockId);
	}

	
	public List<Stock> displayAllStock() {
		// TODO Auto-generated method stub
		return (List<Stock>) stockRepository.findAll();
	}


}
