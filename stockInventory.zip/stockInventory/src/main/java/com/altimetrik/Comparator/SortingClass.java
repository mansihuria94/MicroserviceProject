package com.altimetrik.Comparator;

import java.util.Comparator;

import com.altimetrik.stockInventory.model.Stock;


public class SortingClass {

	
	public static Comparator<Stock> sortByName = new Comparator<Stock>() {
		@Override
		public int compare(Stock s1, Stock s2) {
		return (s1.getStockName().compareTo(s2.getStockName()));
		
		}
	};
 
	public static Comparator<Stock> sortByPurchaseDate = new Comparator<Stock>() {
		@Override
		public int compare(Stock s1, Stock s2) {
		return (s1.getPurchasedDate().compareTo(s2.getPurchasedDate()));
		
		}
	};
	
	public static Comparator<Stock> sortByPurchasePrice = new Comparator<Stock>() {
		@Override
		public int compare(Stock s1, Stock s2) {
		return (s1.getPurchasingPrice() - s2.getPurchasingPrice());
		
		}
	};
}
