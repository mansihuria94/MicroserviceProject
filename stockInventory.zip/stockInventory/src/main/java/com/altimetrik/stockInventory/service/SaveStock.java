package com.altimetrik.stockInventory.service;

import org.springframework.stereotype.Service;

import com.altimetrik.stockInventory.model.Stock;

public interface SaveStock {
	void saveStock(Stock addStock);
}
