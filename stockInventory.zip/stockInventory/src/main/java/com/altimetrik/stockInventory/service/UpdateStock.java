package com.altimetrik.stockInventory.service;

import com.altimetrik.stockInventory.model.Stock;


public interface UpdateStock {
	void updateStock(Stock updateStock);
}
