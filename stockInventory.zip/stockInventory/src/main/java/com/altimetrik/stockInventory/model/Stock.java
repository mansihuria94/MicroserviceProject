package com.altimetrik.stockInventory.model;

import javax.persistence.Entity;

import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class Stock {
	private int stockNumber;
	@Id
	private String stockName;
	private int purchasingPrice;
	private String purchasedDate;
	private long quantity;
	public int getStockNumber() {
		return stockNumber;
	}
	public void setStockNumber(int stockNumber) {
		this.stockNumber = stockNumber;
	}
	public String getStockName() {
		return stockName;
	}
	public void setStockName(String stockName) {
		this.stockName = stockName;
	}
	public int getPurchasingPrice() {
		return purchasingPrice;
	}
	public void setPurchasingPrice(int purchasingPrice) {
		this.purchasingPrice = purchasingPrice;
	}
	public String getPurchasedDate() {
		return purchasedDate;
	}
	public void setPurchasedDate(String purchasedDate) {
		this.purchasedDate = purchasedDate;
	}
	public long getQuantity() {
		return quantity;
	}
	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}
	public Stock(int stockNumber, String stockName, int purchasingPrice, String purchasedDate, long quantity) {
		super();
		this.stockNumber = stockNumber;
		this.stockName = stockName;
		this.purchasingPrice = purchasingPrice;
		this.purchasedDate = purchasedDate;
		this.quantity = quantity;
	}
	public Stock() {
		super();
	}
	
	
	

}
