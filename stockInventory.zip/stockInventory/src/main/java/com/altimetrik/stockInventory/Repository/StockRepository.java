package com.altimetrik.stockInventory.Repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.altimetrik.stockInventory.model.Stock;

@Repository
public interface StockRepository extends CrudRepository<Stock, Integer> {

	Optional<Stock> findByStockName(String name);
}
