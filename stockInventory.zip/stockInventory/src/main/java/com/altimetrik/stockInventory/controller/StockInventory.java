package com.altimetrik.stockInventory.controller;



import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.altimetrik.Comparator.SortingClass;
import com.altimetrik.stockInventory.model.Stock;
import com.altimetrik.stockInvertory.serviceImpl.DisplayStockImpl;
import com.altimetrik.stockInvertory.serviceImpl.SaveStockImpl;
import com.altimetrik.stockInvertory.serviceImpl.UpdateStockImpl;



@RestController
public class StockInventory {
	@Autowired
	private DisplayStockImpl displayStockImpl;
	@Autowired
	private UpdateStockImpl updateStockImpl;
	@Autowired
	private SaveStockImpl  saveStockImpl;
	

	@PostMapping("/create")
	public void createStock(@RequestBody  Stock addStock ) throws Exception {
		
		if(null!= addStock) {
			saveStockImpl.saveStock(addStock);
		}
		else {
			throw new Exception("");
		}
	
	}
	
	@GetMapping("/display/{id}")
	public Stock displayStock( @PathVariable int stockId  ) {
		if(stockId!=0) {
			Optional<Stock> displayResult =displayStockImpl.displayStock(stockId);
			if(displayResult.isPresent()) {
				return displayResult.get();
			}	
		}
		return null;
	
		
		
	}
	
	@PutMapping("/update")
	public void updateStock(@RequestBody  Stock updateStock) {
		try {
		updateStockImpl.updateStock(updateStock);
		}catch(Exception e) {
			System.out.println("Not able to update the data");
		}
	}
	
	@GetMapping("/sortByName")
	public List<Stock> sortByName() {
	
		List<Stock> allAvailableStock= displayStockImpl.displayAllStock();
		if(null!= allAvailableStock) {
			Collections.sort(allAvailableStock, SortingClass.sortByName);
			
		}
		return allAvailableStock;
		
		
	}
	
	@GetMapping("/sortByPurchaseDate")
	public List<Stock> sortByPurchaseDate() {
		List<Stock> allAvailableStock= displayStockImpl.displayAllStock();
		if(null!= allAvailableStock) {
			Collections.sort(allAvailableStock, SortingClass.sortByPurchaseDate);
			
		}
		return allAvailableStock;
		
	}
	
	@GetMapping("/sortByPurchasePrice")
	public List<Stock> sortByPurchasePrice() {
		List<Stock> allAvailableStock= displayStockImpl.displayAllStock();
		if(null!= allAvailableStock) {
			Collections.sort(allAvailableStock, SortingClass.sortByPurchasePrice);
			
		}
		return allAvailableStock;
		
	}
	
}
