package com.altimetrik.stockInventory.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.altimetrik.stockInventory.model.Stock;


public interface DisplayStock {
	Optional<Stock> displayStock(int stockId);
	List<Stock> displayAllStock();
}
